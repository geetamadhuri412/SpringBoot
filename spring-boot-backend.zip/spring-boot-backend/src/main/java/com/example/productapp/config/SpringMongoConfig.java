package com.example.productapp.config;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.client.RestTemplate;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;

@Configuration
public class SpringMongoConfig {
	
	@Value("${spring.data.mongodb.host}")
	private String hostList;
	@Value("${spring.data.mongodb.database}")
	private String database;
	@Value("${spring.data.mongodb.port}")
	private int port;
//	@Value("${spring.data.mongodb.username}")
//	private String userName;
//	@Value("${spring.data.mongodb.password}")
//	private String password;
	
	@Bean
	public MongoClient mongoClient() {
		System.out.println("In Mongo Config");
		MongoClient mongoClient = null;
		String[] mongoDbHostList = hostList.trim().split(",");

		List<ServerAddress> serverList = new ArrayList<ServerAddress>();
		for (int i = 0; i < mongoDbHostList.length; i++) {
			ServerAddress serverAddr = new ServerAddress(mongoDbHostList[i], port);
			serverList.add(serverAddr);
			}

//		List<MongoCredential> credentialsList = new ArrayList<MongoCredential>();
//		for (int i = 0; i < mongoDbHostList.length; i++) {
//			MongoCredential credential = null;
//			credential = MongoCredential.createCredential(userName, database,password.toCharArray()
//			);
//			credentialsList.add(credential);
//			}
			
		WriteConcern MAJORITY = new WriteConcern("majority");
		MongoClientOptions options = MongoClientOptions.builder().writeConcern(MAJORITY).connectionsPerHost(100).connectTimeout(5000).build();
		mongoClient = new MongoClient(serverList, options);
//		mongoClient = new MongoClient(serverList, credentialsList, options);
		return mongoClient;
	}

	@Bean
	public MongoTemplate mongoTemplate() {
		return new MongoTemplate(this.mongoClient(), database);
	}
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public void closeMongoClient() {
		this.mongoClient().close();
	}

	public String getDatabase() {
		return database;
	}

}