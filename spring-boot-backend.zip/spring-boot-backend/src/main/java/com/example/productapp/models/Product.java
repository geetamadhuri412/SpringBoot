package com.example.productapp.models;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Document(collection = "Products")
public class Product {

	@Field("ID")
	@JsonProperty("ID")
	private Integer id;
	@Field("Name")
	@JsonProperty("Name")
	private String name;
	@Field("Price")
	@JsonProperty("Price")
	private Double price;
	@Field("SalesCount")
	@JsonProperty("SalesCount")
	private Long salesCount;
	@Field("Category")
	@JsonProperty("Category")
	private String category;
	@Field("Cust_Rating")
	@JsonProperty("Cust_Rating")
	private Double custRating;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Long getSalesCount() {
		return salesCount;
	}
	public void setSalesCount(Long salesCount) {
		this.salesCount = salesCount;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Double getCustRating() {
		return custRating;
	}
	public void setCustRating(Double custRating) {
		this.custRating = custRating;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", salesCount=" + salesCount
				+ ", category=" + category + ", custRating=" + custRating + "]";
	}

	
}