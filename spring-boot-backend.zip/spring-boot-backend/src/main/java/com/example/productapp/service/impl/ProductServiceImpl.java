package com.example.productapp.service.impl;



import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.productapp.models.Product;
import com.example.productapp.repositories.ProductRepository;
import com.example.productapp.service.ProductService;
import com.mongodb.client.result.UpdateResult;

@Service
@Component
public class ProductServiceImpl implements ProductService{
	
	
    @Autowired
    ProductRepository productRepository;
    
    @Autowired
    MongoTemplate mongoTemplate;
	
    @Override
    public List<Product> getAllProductsSortedByPrice() {
        Sort sortByCreatedAtAsc = new Sort(Sort.Direction.ASC, "Price");
        return productRepository.findAll(sortByCreatedAtAsc);
    }
    
    @Override
    public List<Product> getAllProducts() {
        Query query = new Query();
        return mongoTemplate.find(query, Product.class); 
    }
    
    @Override
    public List<Product> getTopTenProductsBySales() {
    	Query query = new Query();
    	query.with(new Sort(Sort.Direction.DESC, "SalesCount"));
    	query.limit(10);
   		return mongoTemplate.find(query, Product.class); 
    }
 
    @Override
    public void createProducts(Product product) {
 
   		productRepository.save(product);
        
    }
    
    @Override
    public List<Product> getProductByName(String name) {
    	Query query= Query.query(Criteria.where("Name").is(name));
    	return mongoTemplate.find(query, Product.class); 
    }

    @Override
    public List<UpdateResult> updateProducts(List<Product> productList) {
    	List<UpdateResult> result=new ArrayList<UpdateResult>();
    	for(Product product:productList) {
	    	Query query=new Query();
	    	query.addCriteria(Criteria.where("Name").is(product.getName()));
	    	Update update = new Update();
	    	update.set("Name",product.getName());
	    	update.set("Price",product.getPrice());
	    	update.set("Category",product.getCategory());
	    	update.set("SalesCount",product.getSalesCount());
	    	update.set("Cust_Rating",product.getCustRating());
	    	update.set("ID",product.getId());
	    	UpdateResult updateResult=mongoTemplate.upsert(query, update, Product.class);
	    	result.add(updateResult);
    	}
    	return result;
    }
	
}
