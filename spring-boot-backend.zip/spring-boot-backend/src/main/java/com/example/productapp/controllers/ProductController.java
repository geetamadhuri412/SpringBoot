package com.example.productapp.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.example.productapp.models.Product;
import com.example.productapp.service.ProductService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mongodb.client.result.UpdateResult;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	ProductService service;
	List<Product> list=new ArrayList<Product>();

	@GetMapping("/products/price")
	public List<Product> getAllProductsSortedByPrice() {
		list=service.getAllProductsSortedByPrice();
		return list;

	}

	@GetMapping("/products")
	public List<Product> getAllProducts() {

		list= service.getAllProducts();
		return list;
	}


	@GetMapping("/products/TopTenBySales")
	public List<Product> getTopTenProductsBySales() {

		list=service.getTopTenProductsBySales();
		return list;
	}

	@PostMapping("/products")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<String> createProducts(@Valid @RequestBody String input) {
		ObjectMapper objectMapper = new ObjectMapper();
		//Set pretty printing of json
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		List<String> response = new ArrayList<String>();

		TypeReference<List<Product>> mapType = new TypeReference<List<Product>>() {};
		List<Product> jsonToPersonList;
		try {
			jsonToPersonList = objectMapper.readValue(input, mapType);
			for (Product product: jsonToPersonList){
				service.createProducts(product);
				response.add("Saved product: " + product.toString());
			}
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	@GetMapping(value="/products/{name}")
	public List<Product> getProductByName(@PathVariable("name") String name) {

		list= service.getProductByName(name);
		
		return list;
	}

	@PutMapping(value="/products/update")
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public List<UpdateResult> updateInsertProducts(@Valid @RequestBody String input) {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
		TypeReference<List<Product>> mapType = new TypeReference<List<Product>>() {};
		List<Product> jsonToPersonList;
		try {
			jsonToPersonList = objectMapper.readValue(input, mapType);
			return service.updateProducts(jsonToPersonList);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}	


}