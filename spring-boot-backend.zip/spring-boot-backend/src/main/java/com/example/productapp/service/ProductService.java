package com.example.productapp.service;

import java.util.List;


import com.example.productapp.models.Product;
import com.mongodb.client.result.UpdateResult;

public interface ProductService {

	List<Product> getAllProductsSortedByPrice();

	List<Product> getAllProducts();

	List<Product> getTopTenProductsBySales();

	void createProducts(Product products);

	List<Product> getProductByName(String name);

	List<UpdateResult> updateProducts(List<Product> products);

}
